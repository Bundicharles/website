<?php
// ============================================================
// api/setup/create_admin.php
// Run ONCE to create the first admin user, then DELETE this file.
// Access: http://localhost/website/api/setup/create_admin.php
// ============================================================
define('API_ROOT', dirname(__DIR__));
require_once API_ROOT . '/config/config.php';
require_once API_ROOT . '/config/database.php';
require_once API_ROOT . '/src/middleware/response.php';

date_default_timezone_set(TIMEZONE);

// ── Simple form-based setup ───────────────────────────────────
$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $pass     = $_POST['password']      ?? '';
    $confirm  = $_POST['confirm']       ?? '';
    $token    = $_POST['setup_token']   ?? '';

    // Basic token gate (set SETUP_TOKEN env var before running)
    $expectedToken = getenv('SETUP_TOKEN') ?: 'CHANGE_ME_BEFORE_RUNNING';
    if (!hash_equals($expectedToken, $token)) {
        $error = 'Invalid setup token.';
    } elseif (strlen($username) < 3) {
        $error = 'Username must be at least 3 characters.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email address.';
    } elseif (strlen($pass) < 12) {
        $error = 'Password must be at least 12 characters.';
    } elseif ($pass !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        try {
            $db   = getDB();
            $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $db->prepare(
                "INSERT INTO users (username, email, password_hash, display_name, role)
                 VALUES (?,?,?,?,?)"
            );
            $stmt->execute([$username, $email, $hash, ucfirst($username), 'admin']);
            $success = 'Admin user created successfully. DELETE this file immediately!';
        } catch (PDOException $e) {
            $error = 'Could not create user: ' . ($e->getCode() === '23000' ? 'Username or email already exists.' : 'Database error.');
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Habari Hub – First Admin Setup</title>
<style>
body{font-family:system-ui,sans-serif;background:#111;color:#f0f0f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
.box{background:#1e1e1e;padding:2rem;border-radius:8px;width:400px;border:1px solid #333}
h1{color:#c62828;margin-top:0;font-size:1.4rem}
label{display:block;margin:.75rem 0 .25rem;font-size:.875rem;color:#bbb}
input{width:100%;box-sizing:border-box;padding:.5rem .75rem;background:#111;border:1px solid #444;color:#f0f0f0;border-radius:4px;font-size:1rem}
button{width:100%;margin-top:1.25rem;padding:.6rem;background:#c62828;color:#fff;border:none;border-radius:4px;font-size:1rem;cursor:pointer}
button:hover{background:#ef4444}
.error{background:#5c1010;border:1px solid #c62828;padding:.75rem;border-radius:4px;margin-bottom:1rem;color:#fca5a5}
.success{background:#064e3b;border:1px solid #10b981;padding:.75rem;border-radius:4px;margin-bottom:1rem;color:#6ee7b7}
.warn{background:#451a03;border:1px solid #f97316;padding:.5rem .75rem;border-radius:4px;font-size:.8rem;color:#fed7aa;margin-top:1rem}
</style>
</head>
<body>
<div class="box">
  <h1>🔐 First Admin Setup</h1>
  <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <?php if ($success): ?>
    <div class="success"><?= htmlspecialchars($success) ?></div>
    <p style="font-size:.85rem;color:#bbb">You may now <a href="/website/admin/" style="color:#c62828">login to the admin panel</a>.</p>
  <?php else: ?>
  <form method="POST">
    <label>Setup Token</label>
    <input type="password" name="setup_token" required placeholder="Set SETUP_TOKEN env var">
    <label>Username</label>
    <input type="text" name="username" required minlength="3">
    <label>Email</label>
    <input type="email" name="email" required>
    <label>Password (min 12 chars)</label>
    <input type="password" name="password" required minlength="12">
    <label>Confirm Password</label>
    <input type="password" name="confirm" required minlength="12">
    <button type="submit">Create Admin</button>
  </form>
  <?php endif; ?>
  <div class="warn">⚠️ Delete this file immediately after use.</div>
</div>
</body>
</html>
