<?php
/**
 * fix_sample_images.php
 * Run once via browser: http://localhost/website/api/setup/fix_sample_images.php
 * 
 * This script:
 * 1. Creates placeholder images for all sample-*.jpg files missing from uploads
 * 2. Updates DB rows that still reference missing sample images to use placeholder
 */

require_once dirname(__DIR__) . '/config/config.php';
require_once dirname(__DIR__) . '/config/database.php';

$uploadDir = UPLOAD_PATH; // c:/.../api/uploads/images

// ── 1. Create placeholder images for each missing sample file ──
$samples = [
    'sample-economy.jpg'     => [0x22, 0x6B, 0xD7], // blue
    'sample-politics.jpg'    => [0xC6, 0x28, 0x28], // red
    'sample-documentary.jpg' => [0x1B, 0x5E, 0x20], // green
    'sample-counties.jpg'    => [0xE6, 0x5C, 0x00], // orange
    'sample-opinion.jpg'     => [0x4A, 0x14, 0x8C], // purple
];

$created = [];
foreach ($samples as $filename => [$r, $g, $b]) {
    $path = $uploadDir . '/' . $filename;
    if (!file_exists($path)) {
        // Create a 640×360 solid-color JPEG as placeholder
        $img = imagecreatetruecolor(640, 360);
        $bg  = imagecolorallocate($img, $r, $g, $b);
        $fg  = imagecolorallocate($img, 255, 255, 255);
        imagefill($img, 0, 0, $bg);
        // Write label text centered
        $label = strtoupper(str_replace(['-','.jpg'], [' ',''], $filename));
        imagestring($img, 5, 200, 170, $label, $fg);
        imagejpeg($img, $path, 80);
        imagedestroy($img);
        $created[] = $filename;
    }
}

// ── 2. Fix any articles pointing to missing images ─────────────
$db = getDB();

// Check what images exist in uploads/images
$existingFiles = array_map('basename', glob($uploadDir . '/*.*') ?: []);

// Fetch all articles with featured_image set to an uploads path
$rows = $db->query("SELECT id, featured_image FROM articles WHERE featured_image LIKE '/api/uploads/%'")->fetchAll(PDO::FETCH_ASSOC);

$fixed = [];
foreach ($rows as $row) {
    $fname = basename($row['featured_image']);
    if (!in_array($fname, $existingFiles, true)) {
        // Replace missing image with placeholder
        $db->prepare("UPDATE articles SET featured_image = '' WHERE id = ?")
           ->execute([$row['id']]);
        $fixed[] = ['id' => $row['id'], 'was' => $row['featured_image']];
    }
}

// Output result
header('Content-Type: application/json');
echo json_encode([
    'success'         => true,
    'images_created'  => $created,
    'articles_fixed'  => $fixed,
    'message'         => 'Done. Reload your frontend to see changes.',
], JSON_PRETTY_PRINT);
