<?php
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../src/middleware/auth.php';

startSecureSession();
$_SESSION['user_id'] = 1;
$_SESSION['role'] = 'admin';

echo "Session ID: " . session_id() . "\n";
echo "Session user_id: " . $_SESSION['user_id'] . "\n";
$headers = headers_list();
echo "Headers count: " . count($headers) . "\n";
foreach ($headers as $h) {
    if (stripos($h, 'cookie') !== false) {
        echo "Cookie Header: $h\n";
    }
}
